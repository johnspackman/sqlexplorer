<?php include("common/header.php"); ?>

	<h1>Random Screenshots</h1>

	<p>Exporting query results with multiple queries still running in the background.</p>								
	<p><img src="screenshots/screenshot1.jpg" alt="" /></p>
	<p>Viewing DDL information for an Oracle Procedure.</p>								
	<p><img src="screenshots/screenshot2.jpg" alt="" /></p>
	<p>DB2 explain plan for a query.</p>								
	<p><img src="screenshots/screenshot3.jpg" alt="" /></p>
	<p>Extensive filtering options for the database structure view.  In the bottom right corner we can see a new database connection is still being opened in the background.</p>								
	<p><img src="screenshots/screenshot4.jpg" alt="" /></p>
	<p>Easy filtering of query history.</p>								
	<p><img src="screenshots/screenshot5.jpg" alt="" /></p>

<?php include("common/footer.php"); ?>