<?php include("common/header.php"); ?>

	<h1>I can help?  Cool!</h1>
	<p>Do you use SQL Explorer?  Want to contribute something back to the project? 
	If you want to help out, just post a message in the <a href="http://sourceforge.net/forum/forum.php?forum_id=605856">forum</a>.<br />This project needs:</p>
	<p><b>Java Developers</b></p>
	<p>Ecplise SQL Explorer 3.0.0. has come a long way since the initial 2.2.4 version, but there are still plenty of things 
	that can be improved and a lot more database specific features that can be added.  Don't have a lot of experience programming in eclipse?  
	Don't worry, we'll help you along.  Here's your chance to finally do something about your eclipse knowledge!</p>
	<p><b>Database Experts</b></p>
	<p>Ok, maybe not experts, but if you know how to get information out of a database that could help us add new features that would be great!<br/>
	For example, if you know what SQL statement to use to get to the DDL of a DB2 procedure, let us know and we can incorporate that feature into SQL Explorer.</p>
	<p><b>Writers</b></p>
	<p>Eclipse SQL Explorer still doesn't have a good help file.  It's about time to fix this.</p>
	<p><b>Financial Sponsors</b></p>
	<p>Do you use SQL Explorer a lot?  Like it?  Got a dollar to spare?  You can donate it <a href="http://sourceforge.net/project/project_donations.php?group_id=132863">here</a>.
	</p>
					
<?php include("common/footer.php"); ?>